#!/usr/bin/python
# need install cyaron library.

from cyaron import IO, Compare
import random

while True:
    testcase = IO(file_prefix="knapsack")
    n = 4
    w = random.randint(1, 10)
    testcase.input_writeln(n, w)
    for _ in range(0, n):
        cost = random.randint(1, 20)
        weight = random.randint(1, w)
        testcase.input_writeln(weight, cost)
    testcase.output_gen("./std")
    Compare.program("./code", input=testcase, std_program="./std")
